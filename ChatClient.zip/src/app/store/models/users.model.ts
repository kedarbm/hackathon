//The user model interface
export interface UserAdd {
  id : string,
  name : string,
  email : string,
  age : number,
  address : string
}

